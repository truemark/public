import {Construct} from 'constructs';
import {
  SubnetGroup as RdsSubnetGroup,
  SubnetGroupProps,
} from 'aws-cdk-lib/aws-rds';
import {IVpc, SubnetType} from 'aws-cdk-lib/aws-ec2';
import {ExtendedConstructProps, StandardTags} from '../../aws-cdk';

/**
 * Properties for SubnetGroup.
 */
export interface ExtendedSubnetGroupProps
  extends Omit<SubnetGroupProps, 'vpc' | 'vpcSubnets'>,
    ExtendedConstructProps {
  /**
   * The VPC to create the subnet group in.
   */
  readonly vpc: IVpc;

  /**
   * The type of subnets to include in the subnet group. Default is PRIVATE_WITH_EGRESS.
   *
   * @default SubnetType.PRIVATE_WITH_EGRESS
   */
  readonly subnetType?: SubnetType;
}

/**
 * RDS Subnet Group with standard tagging and sensible defaults.
 * This construct creates a subnet group for RDS instances and clusters
 * using private subnets by default for security.
 */
export class SubnetGroup extends RdsSubnetGroup {
  constructor(scope: Construct, id: string, props: ExtendedSubnetGroupProps) {
    const {vpc, subnetType, ...rest} = props;

    super(scope, id, {
      vpc,
      vpcSubnets: {
        subnetType: subnetType ?? SubnetType.PRIVATE_WITH_EGRESS,
      },
      description:
        props.description ?? `Subnet group for RDS resources in ${vpc.node.id}`,
      ...rest,
    });

    new StandardTags(this, props.standardTags);
  }
}
