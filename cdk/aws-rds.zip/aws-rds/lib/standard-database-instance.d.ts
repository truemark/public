import { Construct } from 'constructs';
import { DatabaseInstanceEngine } from 'aws-cdk-lib/aws-rds';
import { InstanceType } from 'aws-cdk-lib/aws-ec2';
import { Duration } from 'aws-cdk-lib';
import { ExtendedDatabaseInstance, ExtendedDatabaseInstanceProps } from './extended-database-instance';
type StandardDatabaseInstancePropsOmitFields = 'instanceType' | 'engine' | 'storageType' | 'allocatedStorage' | 'maxAllocatedStorage' | 'backupRetention' | 'deletionProtection' | 'storageEncrypted' | 'multiAz' | 'autoMinorVersionUpgrade' | 'deleteAutomatedBackups';
export interface StandardDatabaseInstanceProps extends Omit<ExtendedDatabaseInstanceProps, StandardDatabaseInstancePropsOmitFields> {
    /**
     * The database engine to use. Default is PostgreSQL 15.
     *
     * @default DatabaseInstanceEngine.postgres({ version: EngineVersion.VER_15 })
     */
    readonly engine?: DatabaseInstanceEngine;
    /**
     * The instance type for the database. Default is t3.micro.
     *
     * @default InstanceType.of(InstanceClass.T3, InstanceSize.MICRO)
     */
    readonly instanceType?: InstanceType;
    /**
     * The initial amount of storage for the database in GB. Default is 20.
     *
     * @default 20
     */
    readonly allocatedStorage?: number;
    /**
     * The maximum amount of storage for the database in GB. Default is 100.
     *
     * @default 100
     */
    readonly maxAllocatedStorage?: number;
    /**
     * The number of days to retain automated backups. Default is 7.
     *
     * @default 7
     */
    readonly backupRetention?: Duration;
    /**
     * Whether to enable Multi-AZ deployment. Default is false for cost optimization.
     *
     * @default false
     */
    readonly multiAz?: boolean;
    /**
     * Whether to enable deletion protection. Default is true.
     *
     * @default true
     */
    readonly deletionProtection?: boolean;
    /**
     * Whether to enable storage encryption. Default is true.
     *
     * @default true
     */
    readonly storageEncrypted?: boolean;
    /**
     * Whether to enable automatic minor version upgrades. Default is true.
     *
     * @default true
     */
    readonly autoMinorVersionUpgrade?: boolean;
    /**
     * Setting this to true will suppress the creation of default tags on resources
     * created by this construct. Default is false.
     *
     * @default false
     */
    readonly suppressTagging?: boolean;
}
/**
 * Standard RDS Database Instance with opinionated defaults for common use cases.
 * This class provides sensible defaults for PostgreSQL databases with proper
 * backup, encryption, and monitoring configuration.
 */
export declare class StandardDatabaseInstance extends ExtendedDatabaseInstance {
    constructor(scope: Construct, id: string, props?: StandardDatabaseInstanceProps);
}
export {};
