import { Construct } from 'constructs';
import { SubnetGroup as RdsSubnetGroup, SubnetGroupProps } from 'aws-cdk-lib/aws-rds';
import { IVpc, SubnetType } from 'aws-cdk-lib/aws-ec2';
import { ExtendedConstructProps } from '../../aws-cdk';
/**
 * Properties for SubnetGroup.
 */
export interface ExtendedSubnetGroupProps extends Omit<SubnetGroupProps, 'vpc' | 'vpcSubnets'>, ExtendedConstructProps {
    /**
     * The VPC to create the subnet group in.
     */
    readonly vpc: IVpc;
    /**
     * The type of subnets to include in the subnet group. Default is PRIVATE_WITH_EGRESS.
     *
     * @default SubnetType.PRIVATE_WITH_EGRESS
     */
    readonly subnetType?: SubnetType;
}
/**
 * RDS Subnet Group with standard tagging and sensible defaults.
 * This construct creates a subnet group for RDS instances and clusters
 * using private subnets by default for security.
 */
export declare class SubnetGroup extends RdsSubnetGroup {
    constructor(scope: Construct, id: string, props: ExtendedSubnetGroupProps);
}
