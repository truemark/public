import { Construct } from 'constructs';
import { DatabaseInstance, DatabaseCluster } from 'aws-cdk-lib/aws-rds';
import { AlarmsBase, AlarmsBaseOptions } from '../../aws-monitoring';
/**
 * Options for DatabaseAlarms.
 */
export interface DatabaseAlarmsOptions extends AlarmsBaseOptions {
    /**
     * The RDS database instance to monitor.
     */
    readonly databaseInstance?: DatabaseInstance;
    /**
     * The RDS database cluster to monitor.
     */
    readonly databaseCluster?: DatabaseCluster;
    /**
     * CPU utilization threshold for alarms. Default is 80.
     *
     * @default 80
     */
    readonly cpuUtilizationThreshold?: number;
    /**
     * Database connections threshold for alarms. Default is 80% of max connections.
     *
     * @default undefined
     */
    readonly databaseConnectionsThreshold?: number;
    /**
     * Free storage space threshold in bytes for alarms. Default is 2GB.
     *
     * @default 2147483648
     */
    readonly freeStorageSpaceThreshold?: number;
    /**
     * Read latency threshold in seconds for alarms. Default is 0.2.
     *
     * @default 0.2
     */
    readonly readLatencyThreshold?: number;
    /**
     * Write latency threshold in seconds for alarms. Default is 0.2.
     *
     * @default 0.2
     */
    readonly writeLatencyThreshold?: number;
}
/**
 * CloudWatch Alarms for RDS Database instances and clusters.
 */
export declare class DatabaseAlarms extends AlarmsBase {
    readonly databaseInstance?: DatabaseInstance;
    readonly databaseCluster?: DatabaseCluster;
    readonly cpuUtilizationThreshold: number;
    readonly databaseConnectionsThreshold?: number;
    readonly freeStorageSpaceThreshold: number;
    readonly readLatencyThreshold: number;
    readonly writeLatencyThreshold: number;
    constructor(scope: Construct, id: string, props: DatabaseAlarmsOptions);
    private createAlarms;
}
