import { Construct } from 'constructs';
import { DatabaseInstance, DatabaseInstanceProps } from 'aws-cdk-lib/aws-rds';
import { DatabaseAlarms, DatabaseAlarmsOptions } from './database-alarms';
import { ExtendedConstructProps } from '../../aws-cdk';
/**
 * Properties for ExtendedDatabaseInstance.
 */
export interface ExtendedDatabaseInstanceProps extends DatabaseInstanceProps, DatabaseAlarmsOptions, ExtendedConstructProps {
}
/**
 * RDS Database Instance with CloudWatch Alarms and standard tagging.
 */
export declare class ExtendedDatabaseInstance extends DatabaseInstance {
    readonly databaseAlarms?: DatabaseAlarms;
    constructor(scope: Construct, id: string, props: ExtendedDatabaseInstanceProps);
}
