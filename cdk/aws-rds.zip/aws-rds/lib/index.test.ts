// Simple test to verify exports are working
import * as rds from './index';

describe('aws-rds module exports', () => {
  test('should export all constructs', () => {
    expect(rds.DatabaseAlarms).toBeDefined();
    expect(rds.ExtendedDatabaseInstance).toBeDefined();
    expect(rds.StandardDatabaseInstance).toBeDefined();
    expect(rds.ExtendedDatabaseCluster).toBeDefined();
    expect(rds.StandardDatabaseCluster).toBeDefined();
    expect(rds.SubnetGroup).toBeDefined();
  });
});
