import {Construct} from 'constructs';
import {DatabaseInstance, DatabaseCluster} from 'aws-cdk-lib/aws-rds';
import {Metric, Unit} from 'aws-cdk-lib/aws-cloudwatch';
import {
  AlarmFacadeSet,
  AlarmsBase,
  AlarmsOptions,
  AlarmsCategoryOptions,
} from '../../aws-monitoring';
import {CustomAlarmThreshold} from 'cdk-monitoring-constructs';

/**
 * Options for DatabaseAlarms.
 */
export interface DatabaseAlarmsOptions extends AlarmsBaseOptions {
  /**
   * The RDS database instance to monitor.
   */
  readonly databaseInstance?: DatabaseInstance;

  /**
   * The RDS database cluster to monitor.
   */
  readonly databaseCluster?: DatabaseCluster;

  /**
   * CPU utilization threshold for alarms. Default is 80.
   *
   * @default 80
   */
  readonly cpuUtilizationThreshold?: number;

  /**
   * Database connections threshold for alarms. Default is 80% of max connections.
   *
   * @default undefined
   */
  readonly databaseConnectionsThreshold?: number;

  /**
   * Free storage space threshold in bytes for alarms. Default is 2GB.
   *
   * @default 2147483648
   */
  readonly freeStorageSpaceThreshold?: number;

  /**
   * Read latency threshold in seconds for alarms. Default is 0.2.
   *
   * @default 0.2
   */
  readonly readLatencyThreshold?: number;

  /**
   * Write latency threshold in seconds for alarms. Default is 0.2.
   *
   * @default 0.2
   */
  readonly writeLatencyThreshold?: number;
}

/**
 * CloudWatch Alarms for RDS Database instances and clusters.
 */
export class DatabaseAlarms extends AlarmsBase {
  readonly databaseInstance?: DatabaseInstance;
  readonly databaseCluster?: DatabaseCluster;
  readonly cpuUtilizationThreshold: number;
  readonly databaseConnectionsThreshold?: number;
  readonly freeStorageSpaceThreshold: number;
  readonly readLatencyThreshold: number;
  readonly writeLatencyThreshold: number;

  constructor(scope: Construct, id: string, props: DatabaseAlarmsOptions) {
    super(scope, id, props);

    this.databaseInstance = props.databaseInstance;
    this.databaseCluster = props.databaseCluster;
    this.cpuUtilizationThreshold = props.cpuUtilizationThreshold ?? 80;
    this.databaseConnectionsThreshold = props.databaseConnectionsThreshold;
    this.freeStorageSpaceThreshold =
      props.freeStorageSpaceThreshold ?? 2147483648; // 2GB
    this.readLatencyThreshold = props.readLatencyThreshold ?? 0.2;
    this.writeLatencyThreshold = props.writeLatencyThreshold ?? 0.2;

    this.createAlarms();
  }

  private createAlarms(): void {
    const resourceId =
      this.databaseInstance?.instanceIdentifier ??
      this.databaseCluster?.clusterIdentifier;
    if (!resourceId) {
      throw new Error(
        'Either databaseInstance or databaseCluster must be provided',
      );
    }

    const isCluster = !!this.databaseCluster;
    const namespace = 'AWS/RDS';
    const dimensionName = isCluster
      ? 'DBClusterIdentifier'
      : 'DBInstanceIdentifier';

    // CPU Utilization Alarm
    const cpuMetric = new Metric({
      namespace,
      metricName: 'CPUUtilization',
      dimensionsMap: {
        [dimensionName]: resourceId,
      },
      unit: Unit.PERCENT,
    });

    new AlarmFacade(this, 'CpuUtilizationAlarm', {
      alarmName: `${resourceId}-cpu-utilization`,
      alarmDescription: `High CPU utilization for RDS ${isCluster ? 'cluster' : 'instance'} ${resourceId}`,
      metric: cpuMetric,
      threshold: this.cpuUtilizationThreshold,
      evaluationPeriods: 2,
      datapointsToAlarm: 2,
      actionsStrategy: new StandardAlarmActionsStrategy(this, 'CpuActions', {
        ...this.actionsStrategyProps,
      }),
    });

    // Database Connections Alarm (if threshold provided)
    if (this.databaseConnectionsThreshold) {
      const connectionsMetric = new Metric({
        namespace,
        metricName: 'DatabaseConnections',
        dimensionsMap: {
          [dimensionName]: resourceId,
        },
        unit: Unit.COUNT,
      });

      new AlarmFacade(this, 'DatabaseConnectionsAlarm', {
        alarmName: `${resourceId}-database-connections`,
        alarmDescription: `High database connections for RDS ${isCluster ? 'cluster' : 'instance'} ${resourceId}`,
        metric: connectionsMetric,
        threshold: this.databaseConnectionsThreshold,
        evaluationPeriods: 2,
        datapointsToAlarm: 2,
        actionsStrategy: new StandardAlarmActionsStrategy(
          this,
          'ConnectionsActions',
          {
            ...this.actionsStrategyProps,
          },
        ),
      });
    }

    // Free Storage Space Alarm (for instances only)
    if (!isCluster) {
      const freeStorageMetric = new Metric({
        namespace,
        metricName: 'FreeStorageSpace',
        dimensionsMap: {
          [dimensionName]: resourceId,
        },
        unit: Unit.BYTES,
      });

      new AlarmFacade(this, 'FreeStorageSpaceAlarm', {
        alarmName: `${resourceId}-free-storage-space`,
        alarmDescription: `Low free storage space for RDS instance ${resourceId}`,
        metric: freeStorageMetric,
        threshold: this.freeStorageSpaceThreshold,
        comparisonOperator: 'LessThanThreshold',
        evaluationPeriods: 1,
        datapointsToAlarm: 1,
        actionsStrategy: new StandardAlarmActionsStrategy(
          this,
          'StorageActions',
          {
            ...this.actionsStrategyProps,
          },
        ),
      });
    }

    // Read Latency Alarm
    const readLatencyMetric = new Metric({
      namespace,
      metricName: 'ReadLatency',
      dimensionsMap: {
        [dimensionName]: resourceId,
      },
      unit: Unit.SECONDS,
    });

    new AlarmFacade(this, 'ReadLatencyAlarm', {
      alarmName: `${resourceId}-read-latency`,
      alarmDescription: `High read latency for RDS ${isCluster ? 'cluster' : 'instance'} ${resourceId}`,
      metric: readLatencyMetric,
      threshold: this.readLatencyThreshold,
      evaluationPeriods: 2,
      datapointsToAlarm: 2,
      actionsStrategy: new StandardAlarmActionsStrategy(
        this,
        'ReadLatencyActions',
        {
          ...this.actionsStrategyProps,
        },
      ),
    });

    // Write Latency Alarm
    const writeLatencyMetric = new Metric({
      namespace,
      metricName: 'WriteLatency',
      dimensionsMap: {
        [dimensionName]: resourceId,
      },
      unit: Unit.SECONDS,
    });

    new AlarmFacade(this, 'WriteLatencyAlarm', {
      alarmName: `${resourceId}-write-latency`,
      alarmDescription: `High write latency for RDS ${isCluster ? 'cluster' : 'instance'} ${resourceId}`,
      metric: writeLatencyMetric,
      threshold: this.writeLatencyThreshold,
      evaluationPeriods: 2,
      datapointsToAlarm: 2,
      actionsStrategy: new StandardAlarmActionsStrategy(
        this,
        'WriteLatencyActions',
        {
          ...this.actionsStrategyProps,
        },
      ),
    });
  }
}
