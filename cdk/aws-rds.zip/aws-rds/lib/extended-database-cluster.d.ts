import { Construct } from 'constructs';
import { DatabaseCluster, DatabaseClusterProps } from 'aws-cdk-lib/aws-rds';
import { DatabaseAlarms, DatabaseAlarmsOptions } from './database-alarms';
import { ExtendedConstructProps } from '../../aws-cdk';
/**
 * Properties for ExtendedDatabaseCluster.
 */
export interface ExtendedDatabaseClusterProps extends DatabaseClusterProps, DatabaseAlarmsOptions, ExtendedConstructProps {
}
/**
 * RDS Database Cluster (Aurora) with CloudWatch Alarms and standard tagging.
 */
export declare class ExtendedDatabaseCluster extends DatabaseCluster {
    readonly databaseAlarms?: DatabaseAlarms;
    constructor(scope: Construct, id: string, props: ExtendedDatabaseClusterProps);
}
