import { Construct } from 'constructs';
import { DatabaseClusterEngine } from 'aws-cdk-lib/aws-rds';
import { InstanceType } from 'aws-cdk-lib/aws-ec2';
import { Duration } from 'aws-cdk-lib';
import { ExtendedDatabaseCluster, ExtendedDatabaseClusterProps } from './extended-database-cluster';
type StandardDatabaseClusterPropsOmitFields = 'engine' | 'writer' | 'readers' | 'backupProps' | 'deletionProtection' | 'storageEncrypted' | 'defaultDatabaseName';
export interface StandardDatabaseClusterProps extends Omit<ExtendedDatabaseClusterProps, StandardDatabaseClusterPropsOmitFields> {
    /**
     * The database engine to use. Default is Aurora PostgreSQL 15.
     *
     * @default DatabaseClusterEngine.auroraPostgres({ version: AuroraPostgresEngineVersion.VER_15_4 })
     */
    readonly engine?: DatabaseClusterEngine;
    /**
     * The instance type for the writer instance. Default is t4g.medium.
     *
     * @default InstanceType.of(InstanceClass.T4G, InstanceSize.MEDIUM)
     */
    readonly writerInstanceType?: InstanceType;
    /**
     * The instance type for reader instances. Default is same as writer.
     *
     * @default Same as writerInstanceType
     */
    readonly readerInstanceType?: InstanceType;
    /**
     * The number of reader instances to create. Default is 0.
     *
     * @default 0
     */
    readonly readers?: number;
    /**
     * The number of days to retain automated backups. Default is 7.
     *
     * @default 7
     */
    readonly backupRetention?: Duration;
    /**
     * Whether to enable deletion protection. Default is true.
     *
     * @default true
     */
    readonly deletionProtection?: boolean;
    /**
     * Whether to enable storage encryption. Default is true.
     *
     * @default true
     */
    readonly storageEncrypted?: boolean;
    /**
     * The name of the default database to create. Default is 'app'.
     *
     * @default 'app'
     */
    readonly defaultDatabaseName?: string;
    /**
     * Setting this to true will suppress the creation of default tags on resources
     * created by this construct. Default is false.
     *
     * @default false
     */
    readonly suppressTagging?: boolean;
}
/**
 * Standard RDS Aurora Database Cluster with opinionated defaults for common use cases.
 * This class provides sensible defaults for Aurora PostgreSQL clusters with proper
 * backup, encryption, and monitoring configuration.
 */
export declare class StandardDatabaseCluster extends ExtendedDatabaseCluster {
    constructor(scope: Construct, id: string, props?: StandardDatabaseClusterProps);
}
export {};
