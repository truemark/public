import {Construct} from 'constructs';
import {
  DatabaseClusterEngine,
  ClusterInstance,
  BackupProps,
  AuroraPostgresEngineVersion,
} from 'aws-cdk-lib/aws-rds';
import {InstanceType, InstanceClass, InstanceSize} from 'aws-cdk-lib/aws-ec2';
import {Duration} from 'aws-cdk-lib';
import {
  ExtendedDatabaseCluster,
  ExtendedDatabaseClusterProps,
} from './extended-database-cluster';

type StandardDatabaseClusterPropsOmitFields =
  | 'engine'
  | 'writer'
  | 'readers'
  | 'backupProps'
  | 'deletionProtection'
  | 'storageEncrypted'
  | 'defaultDatabaseName';

export interface StandardDatabaseClusterProps
  extends Omit<
    ExtendedDatabaseClusterProps,
    StandardDatabaseClusterPropsOmitFields
  > {
  /**
   * The database engine to use. Default is Aurora PostgreSQL 15.
   *
   * @default DatabaseClusterEngine.auroraPostgres({ version: AuroraPostgresEngineVersion.VER_15_4 })
   */
  readonly engine?: DatabaseClusterEngine;

  /**
   * The instance type for the writer instance. Default is t4g.medium.
   *
   * @default InstanceType.of(InstanceClass.T4G, InstanceSize.MEDIUM)
   */
  readonly writerInstanceType?: InstanceType;

  /**
   * The instance type for reader instances. Default is same as writer.
   *
   * @default Same as writerInstanceType
   */
  readonly readerInstanceType?: InstanceType;

  /**
   * The number of reader instances to create. Default is 0.
   *
   * @default 0
   */
  readonly readers?: number;

  /**
   * The number of days to retain automated backups. Default is 7.
   *
   * @default 7
   */
  readonly backupRetention?: Duration;

  /**
   * Whether to enable deletion protection. Default is true.
   *
   * @default true
   */
  readonly deletionProtection?: boolean;

  /**
   * Whether to enable storage encryption. Default is true.
   *
   * @default true
   */
  readonly storageEncrypted?: boolean;

  /**
   * The name of the default database to create. Default is 'app'.
   *
   * @default 'app'
   */
  readonly defaultDatabaseName?: string;

  /**
   * Setting this to true will suppress the creation of default tags on resources
   * created by this construct. Default is false.
   *
   * @default false
   */
  readonly suppressTagging?: boolean;
}

/**
 * Standard RDS Aurora Database Cluster with opinionated defaults for common use cases.
 * This class provides sensible defaults for Aurora PostgreSQL clusters with proper
 * backup, encryption, and monitoring configuration.
 */
export class StandardDatabaseCluster extends ExtendedDatabaseCluster {
  constructor(
    scope: Construct,
    id: string,
    props?: StandardDatabaseClusterProps,
  ) {
    const {
      engine,
      writerInstanceType,
      readerInstanceType,
      readers,
      backupRetention,
      deletionProtection,
      storageEncrypted,
      defaultDatabaseName,
      ...rest
    } = props ?? {};

    const backupProps: BackupProps = {
      retention: backupRetention ?? Duration.days(7),
      preferredWindow: '03:00-04:00', // 3-4 AM UTC
    };

    const writerInstance =
      writerInstanceType ??
      InstanceType.of(InstanceClass.T4G, InstanceSize.MEDIUM);
    const readerInstance = readerInstanceType ?? writerInstance;

    // Create reader instances
    const readerInstances: ClusterInstance[] = [];
    const readerCount = readers ?? 0;
    for (let i = 0; i < readerCount; i++) {
      readerInstances.push(
        ClusterInstance.provisioned(`Reader${i + 1}`, {
          instanceType: readerInstance,
        }),
      );
    }

    super(scope, id, {
      engine:
        engine ??
        DatabaseClusterEngine.auroraPostgres({
          version: AuroraPostgresEngineVersion.VER_15_4,
        }),
      writer: ClusterInstance.provisioned('Writer', {
        instanceType: writerInstance,
      }),
      readers: readerInstances,
      storageEncrypted: storageEncrypted ?? true,
      deletionProtection: deletionProtection ?? true,
      defaultDatabaseName: defaultDatabaseName ?? 'app',
      backupProps,
      preferredMaintenanceWindow: 'sun:04:00-sun:05:00', // Sunday 4-5 AM UTC
      // Set default alarm thresholds for standard clusters
      cpuUtilizationThreshold: props?.cpuUtilizationThreshold ?? 80,
      readLatencyThreshold: props?.readLatencyThreshold ?? 0.2,
      writeLatencyThreshold: props?.writeLatencyThreshold ?? 0.2,
      ...rest,
    });
  }
}
