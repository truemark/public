# AWS RDS Module

This module provides AWS CDK constructs for Amazon RDS (Relational Database Service) with built-in monitoring, alarms, and opinionated defaults.

## Constructs

### StandardDatabaseInstance

A PostgreSQL RDS instance with sensible defaults for common use cases:

```typescript
import {StandardDatabaseInstance} from 'truemark-cdk-lib/aws-rds';

const database = new StandardDatabaseInstance(this, 'Database', {
    vpc: myVpc,
    credentials: rds.Credentials.fromGeneratedSecret('admin'),
});
```

**Features:**

- PostgreSQL 15 by default
- t3.micro instance type (cost-optimized)
- GP3 storage with auto-scaling (20GB initial, 100GB max)
- 7-day backup retention
- Deletion protection enabled
- Storage encryption enabled
- Automatic CloudWatch alarms for CPU, storage, and latency

### ExtendedDatabaseInstance

Extends AWS CDK's `DatabaseInstance` with monitoring and tagging:

```typescript
import {ExtendedDatabaseInstance} from 'truemark-cdk-lib/aws-rds';

const database = new ExtendedDatabaseInstance(this, 'Database', {
    engine: rds.DatabaseInstanceEngine.mysql({
        version: rds.MysqlEngineVersion.VER_8_0,
    }),
    instanceType: ec2.InstanceType.of(
        ec2.InstanceClass.T3,
        ec2.InstanceSize.SMALL,
    ),
    vpc: myVpc,
    credentials: rds.Credentials.fromGeneratedSecret('admin'),
    cpuUtilizationThreshold: 85,
    freeStorageSpaceThreshold: 1073741824, // 1GB
});
```

### StandardDatabaseCluster

An Aurora PostgreSQL cluster with sensible defaults:

```typescript
import {StandardDatabaseCluster} from 'truemark-cdk-lib/aws-rds';

const cluster = new StandardDatabaseCluster(this, 'Cluster', {
    vpc: myVpc,
    credentials: rds.Credentials.fromGeneratedSecret('admin'),
    readers: 1, // Add one read replica
});
```

**Features:**

- Aurora PostgreSQL 15.4 by default
- t4g.medium instances
- Storage encryption enabled
- 7-day backup retention
- Deletion protection enabled
- Automatic CloudWatch alarms

### ExtendedDatabaseCluster

Extends AWS CDK's `DatabaseCluster` with monitoring and tagging:

```typescript
import {ExtendedDatabaseCluster} from 'truemark-cdk-lib/aws-rds';

const cluster = new ExtendedDatabaseCluster(this, 'Cluster', {
    engine: rds.DatabaseClusterEngine.auroraMysql({
        version: rds.AuroraMysqlEngineVersion.VER_8_0_28,
    }),
    writer: rds.ClusterInstance.provisioned('Writer', {
        instanceType: ec2.InstanceType.of(
            ec2.InstanceClass.R6G,
            ec2.InstanceSize.LARGE,
        ),
    }),
    vpc: myVpc,
    credentials: rds.Credentials.fromGeneratedSecret('admin'),
});
```

### SubnetGroup

Creates an RDS subnet group with private subnets:

```typescript
import {SubnetGroup} from 'truemark-cdk-lib/aws-rds';

const subnetGroup = new SubnetGroup(this, 'SubnetGroup', {
    vpc: myVpc,
    description: 'Subnet group for RDS instances',
});
```

### DatabaseAlarms

Standalone CloudWatch alarms for RDS resources:

```typescript
import {DatabaseAlarms} from 'truemark-cdk-lib/aws-rds';

const alarms = new DatabaseAlarms(this, 'DatabaseAlarms', {
    databaseInstance: myDatabase,
    cpuUtilizationThreshold: 80,
    freeStorageSpaceThreshold: 2147483648, // 2GB
    readLatencyThreshold: 0.2,
    writeLatencyThreshold: 0.2,
});
```

## Monitoring

All constructs include comprehensive CloudWatch monitoring:

- **CPU Utilization**: Alerts when CPU usage exceeds threshold
- **Database Connections**: Monitors connection count (if threshold set)
- **Free Storage Space**: Alerts when storage is running low (instances only)
- **Read/Write Latency**: Monitors database performance

## Security

- Storage encryption enabled by default
- Private subnet deployment via SubnetGroup
- Integration with AWS Secrets Manager for credentials
- Deletion protection enabled by default

## Cost Optimization

- Standard constructs use cost-effective instance types
- GP3 storage for better price/performance
- Configurable Multi-AZ (disabled by default for cost savings)
- Auto-scaling storage to avoid over-provisioning
